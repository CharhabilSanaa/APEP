<?php

error_reporting(E_ALL);
ini_set('display_errors', '1');

?>
<!DOCTYPE html>
<html lang="fr">
<head>

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>APEP Dashboard</title>

    <?php

    //header NAV Bar
    include 'vue/header.php';

    ?>

</head>

        <body>


        <div class="wrapper">

            <div id="page-wrapper">
                <div id="barre_gab_hs">
                    <div class="row page-header">

                                 <input type="hidden" id="hdnSession" data-value="10"/>
                                <h1>Upload Excel File</h1>


                    </div>
                </div>




                <?php
                //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                $Services_array = array('Transfert d’argent', 'Paiement commerçant Push', 'Paiement commerçant Pull', 'Cash out GAB', 'QR code transfert'
                , 'QR code paiement Push', 'Transfert 2PC', 'Paiement 2PC', 'Paiement CMR 2PC');


                $html="";

                require('library/php-excel-reader/excel_reader2.php');
                require('library/SpreadsheetReader.php');
                // require('db_config.php');

                //if(isset($_POST['Submit']))
                {

                    $_FILES["file"]["type"] = "application/vnd.ms-excel";
                    $mimes = array( 'application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','text/xls','text/xlsx','application/vnd.oasis.opendocument.spreadsheet');
                    if(in_array($_FILES["file"]["type"],$mimes))
                    {

                        //$uploadFilePath = dirname(__FILE__)."/achraf_file/".basename($_FILES['file']['name']);
                        $uploadFilePath = dirname(__FILE__)."/achraf_file/ETAT HOMOLOGATION MEMBRES.xlsx";

                        //move_uploaded_file($_FILES['file']['tmp_name'], $uploadFilePath);

                        $Reader = new SpreadsheetReader($uploadFilePath);

                        $totalSheet = count($Reader->sheets());

                        $table_banque="<h5>Banque : </h5><table class='tutorial-table'>
                        <tr>
                            <th>#</th>
                            <th>Services</th>
                            <th>ABB</th>
                            <th>BCP</th>
                            <th>CAM</th>
                            <th>SGMA</th>
                            <th>CIH</th>
                            <th>BOA</th>
                            <th>ATW</th>
                           <th>CFG</th>
                           <th>CDM</th>
                        </tr>";
                        $table_edp="<h5>EDP : </h5><table class='tutorial-table'>
                        <tr>
                            <th>#</th>
                            <th>Services</th>
                            <th>WAFA CASH</th>
                            <th>M2T</th>
                            <th>CMI</th>
                            <th>NAPS</th>
                            <th>ORANGE</th>
                            <th>INWI</th>
                            <th>IAM</th>
                            <th>MSF</th>
                            <th>FPAY</th>
                            <th>BARID CASH</th>
                            <th>Cash Plus</th>
                            <th>DIGIFI</th>
                            <th>LANA CASH</th>
                            <th>DAMANE CASH</th>
                            <th>FILAHI CASH</th>
                        </tr>";





                        /* For Loop for all sheets */
                        for($j=0;$j<$totalSheet;$j++)
                        {
                            $Payeur = 1;
                            $integ = 1;

                            if ($j==0) {$html .=  $table_banque;}
                            else{$html .= $table_edp;}
                            $Reader->ChangeSheet($j);

                            $i=0;
                            foreach ($Reader as $Row)
                            {

                                //echo "<pre>";print_r($Row);echo "</pre>";

                                if ($Row[1] === 'Payé'){$Payeur = 0;}
                                if ($Row[1] === 'Payeur ') {$Payeur = 1;}
                                if ($Row[1] === 'Homologation') {$integ = 0;}
                                if ($Row[1] === 'Intégration') {$integ = 1;}

                                //echo "Payeur : ";var_dump($Payeur);echo "<br>";
                                //echo $Row[1]." -- Intégration : ";var_dump($integ);echo "<br>";
                                $html.="<tr>";
                                $Services = isset($Row[0]) ? $Row[0] : '';
                                if ($j==0)
                                {
                                    $ABB = isset($Row[1]) ? $Row[1] : '';
                                    $BCP = isset($Row[2]) ? $Row[2] : '';
                                    $CAM = isset($Row[3]) ? $Row[3] : '';
                                    $SGMA = isset($Row[4]) ? $Row[4] : '';
                                    $CIH = isset($Row[5]) ? $Row[5] : '';
                                    $BOA = isset($Row[6]) ? $Row[6] : '';
                                    $ATW = isset($Row[7]) ? $Row[7] : '';
                                    $CFG = isset($Row[8]) ? $Row[8] : '';
                                    $CDM = isset($Row[9]) ? $Row[9] : '';


                                }

                                else
                                {
                                    $WAFA_CASH = isset($Row[1]) ? $Row[1] : '';
                                    $M2T = isset($Row[2]) ? $Row[2] : '';
                                    $CMI = isset($Row[3]) ? $Row[3] : '';
                                    $NAPS = isset($Row[4]) ? $Row[4] : '';
                                    $ORANGE = isset($Row[5]) ? $Row[5] : '';
                                    $INWI = isset($Row[6]) ? $Row[6] : '';
                                    $IAM = isset($Row[7]) ? $Row[7] : '';
                                    $MSF = isset($Row[8]) ? $Row[8] : '';
                                    $FPAY = isset($Row[9]) ? $Row[9] : '';
                                    $CASH_BARID = isset($Row[10]) ? $Row[10] : '';
                                    $Cash_Plus = isset($Row[11]) ? $Row[11] : '';
                                    $DIGIFI = isset($Row[12]) ? $Row[12] : '';
                                    $LANA_CASH = isset($Row[13]) ? $Row[13] : '';
                                    $DAMANE_CASH = isset($Row[14]) ? $Row[14] : '';
                                    $FILAHI_CASH = isset($Row[15]) ? $Row[15] : '';
                                }


                                if (in_array($Services, $Services_array))
                                {
                                    $i++;

                                    $html.="<td>".$i."</td>";
                                    $html.="<td>".$Services."</td>";
                                    if ($j==0)
                                    {

                                        $html.="<td>".$ABB."</td>";
                                        $html.="<td>".$BCP."</td>";
                                        $html.="<td>".$CAM."</td>";
                                        $html.="<td>".$SGMA."</td>";
                                        $html.="<td>".$CIH."</td>";
                                        $html.="<td>".$BOA."</td>";
                                        $html.="<td>".$ATW."</td>";
                                        $html.="<td>".$CFG."</td>";
                                        $html.="<td>".$CDM."</td>";

                                        $array_bank[] = array (
                                            array($Services,"ABB",$ABB,$Payeur,$integ),
                                            array($Services,"BCP",$BCP,$Payeur,$integ),
                                            array($Services,"CAM",$CAM,$Payeur,$integ),
                                            array($Services,"SGMA",$SGMA,$Payeur,$integ),
                                            array($Services,"CIH",$CIH,$Payeur,$integ),
                                            array($Services,"BOA",$BOA,$Payeur,$integ),
                                            array($Services,"ATW",$ATW,$Payeur,$integ),
                                            array($Services,"CFG",$CFG,$Payeur,$integ),
                                            array($Services,"CDM",$CDM,$Payeur,$integ)


                                        );
                                    }
                                    else
                                    {
                                        $html.="<td>".$WAFA_CASH."</td>";
                                        $html.="<td>".$M2T."</td>";
                                        $html.="<td>".$CMI."</td>";
                                        $html.="<td>".$NAPS."</td>";
                                        $html.="<td>".$ORANGE."</td>";
                                        $html.="<td>".$INWI."</td>";
                                        $html.="<td>".$IAM."</td>";
                                        $html.="<td>".$MSF."</td>";
                                        $html.="<td>".$FPAY."</td>";
                                        $html.="<td>".$CASH_BARID."</td>";
                                        $html.="<td>".$Cash_Plus."</td>";
                                        $html.="<td>".$DIGIFI."</td>";
                                        $html.="<td>".$LANA_CASH."</td>";
                                        $html.="<td>".$DAMANE_CASH."</td>";
                                        $html.="<td>".$FILAHI_CASH."</td>";

                                        $array_edp[] = array (
                                            array($Services,"WAFA_CASH",$WAFA_CASH,$Payeur,$integ),
                                            array($Services,"M2T",$M2T,$Payeur,$integ),
                                            array($Services,"CMI",$CMI,$Payeur,$integ),
                                            array($Services,"NAPS",$NAPS,$Payeur,$integ),
                                            array($Services,"ORANGE",$ORANGE,$Payeur,$integ),
                                            array($Services,"INWI",$INWI,$Payeur,$integ),
                                            array($Services,"IAM",$IAM,$Payeur,$integ),
                                            array($Services,"MSF",$MSF,$Payeur,$integ),
                                            array($Services,"FPAY",$FPAY,$Payeur,$integ),
                                            array($Services,"CASH_BARID",$CASH_BARID,$Payeur,$integ),
                                            array($Services,"Cash_Plus",$Cash_Plus,$Payeur,$integ),
                                            array($Services,"DIGIFI",$DIGIFI,$Payeur,$integ),
                                            array($Services,"LANA_CASH",$LANA_CASH,$Payeur,$integ),
                                            array($Services,"DAMANE_CASH",$DAMANE_CASH,$Payeur,$integ),
                                            array($Services,"FILAHI_CASH",$FILAHI_CASH,$Payeur,$integ)
                                        );
                                    }
                                    $html.="</tr>";
                                }

                            }
                            $html .= "</table><br>";
                        }

                        $type = "success";
                        $message = "Excel Data Imported into the Database";

                    }
                    else
                    {
                        $type = "error";
                        $message = "Invalid File Type. Upload Excel File";
                    }
                    //echo "<pre>";print_r($array_bank);echo "</pre>";
                    //echo "<pre>";print_r($array_edp);echo "</pre>";
                    foreach($array_bank as $number => $number_array)
                    {
                        foreach($number_array as $data => $user_data)
                        {
                            print " contains $data with $user_data[0].  <br>";
                            print " contains $data with $user_data[1].  <br>";
                            print " contains $data with $user_data[2].  <br>";
                            print " contains $data with $user_data[3].  <br>";
                            print " contains $data with $user_data[4].  <br><br>";
                        }
                        echo "**************************************************************<br><br>";
                    }
                }



                ?>
                <div id="response"  class="<?php if(!empty($type)) { echo $type . " display-block"; } ?>">
                    <?php if(!empty($message)) { echo $message; } ?>
                </div>
                <?php echo $html."<br>"; ?>

            </div>
        </div>



        </body>

</html>
