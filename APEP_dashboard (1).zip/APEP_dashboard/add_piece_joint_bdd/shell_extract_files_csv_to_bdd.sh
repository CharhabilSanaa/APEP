#!/bin/sh
# Parametrage des fichiers
#wget --no-check-certificate  https://192.168.1.110/mailing/sgma/sgma_dashboard/add_piece_joint_bdd/dsb_bank_auth_activity_csv.php -O /var/www/html/mailing/sgma/sgma_dashboard/add_piece_joint_bdd/log/activite_transactionnelle_csv.html
echo "" > /var/mail/root

# bash /var/www/html/mailing/sgma/sgma_dashboard/add_piece_joint_bdd/insert_vers_bdd.sh

