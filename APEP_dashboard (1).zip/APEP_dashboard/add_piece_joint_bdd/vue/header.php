

    <meta charset="utf-8">

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- MetisMenu CSS -->

    <!-- Custom CSS -->
    <link href="dist/css/sb-admin-2.css" rel="stylesheet">
    <!-- style CSS -->
    <link href="dist/css/style.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="vendor/bootstrap/css/bootstrap-datetimepicker.min.css" rel="stylesheet">
    <link href="vendor/bootstrap/css/bootstrap-select.css" rel="stylesheet">
    <link href="vendor/bootstrap/dataTables/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css" >
    <link href="vendor/bootstrap/dataTables/css/buttons.dataTables.min.css" rel="stylesheet" type="text/css" >
    <link href="vendor/bootstrap/dataTables/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" >
    <link href="vendor/bootstrap/css/toggle.min.css" rel="stylesheet">


    <style>
        .toggle.ios, .toggle-on.ios, .toggle-off.ios { border-radius: 20rem; }
        .toggle.ios .toggle-handle { border-radius: 20rem; }
    </style>

    <style>
        body {
            font-family: Arial;

        }
        #response {
            padding: 10px;
            margin-top: 10px;
            border-radius: 2px;
            display: none;
        }
        div#response.display-block {
            display: block;
        }
        .success {
            background: #c7efd9;
            border: #bbe2cd 1px solid;
        }

        .error {
            background: #fbcfcf;
            border: #f3c6c7 1px solid;
        }
        .tutorial-table {
            margin-top: 40px;
            font-size: 0.8em;
            border-collapse: collapse;
            width: 100%;
        }

        .tutorial-table th {
            background: #f0f0f0;
            border-bottom: 1px solid #dddddd;
            padding: 8px;
            text-align: left;
        }

        .tutorial-table td {
            background: #FFF;
            border-bottom: 1px solid #dddddd;
            padding: 8px;
            text-align: left;
        }
    </style>

